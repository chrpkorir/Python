# A program to add two numbers

num1 = 3
num2 = 4

# Add two numbers
sum = num1 + num2

# Display the sum
print ('The sum of {0} and {1} is {2}'.format(num1, num2, sum))